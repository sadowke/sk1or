import javafx.application.Application;
import javafx.embed.swing.JFXPanel;
import javafx.scene.Scene;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import javafx.stage.Stage;
import javax.swing.*;
import java.awt.*;
import java.io.File;

public class AbdulrahimApp extends JFrame {

    public AbdulrahimApp() {
        // إعداد عنوان التطبيق
        setTitle("Abdulrahim's App");

        // إعداد حجم الإطار
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // إعداد اللوحة المحتوية على JavaFX
        JFXPanel fxPanel = new JFXPanel();
        add(fxPanel, BorderLayout.CENTER);

        // إعداد العناصر الرسومية
        JPanel panel = new JPanel();
        panel.setLayout(new GridBagLayout());
        panel.setOpaque(false); // لتمكين عرض الفيديو في الخلفية

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.CENTER;

        JLabel nameLabel = new JLabel("Welcome to Abdulrahim's App");
        nameLabel.setForeground(Color.WHITE);
        nameLabel.setFont(new Font("Arial", Font.BOLD, 16));
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(nameLabel, gbc);

        JButton instaButton = new JButton("Visit Instagram");
        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(instaButton, gbc);

        JButton snapButton = new JButton("Visit Snapchat");
        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(snapButton, gbc);

        instaButton.addActionListener(e -> openLink("https://www.instagram.com/alk3bi_kw"));
        snapButton.addActionListener(e -> openLink("https://www.snapchat.com/add/alk3bi_q8"));

        add(panel);

        // تحميل وتشغيل الفيديو باستخدام JavaFX
        Platform.runLater(() -> {
            File videoFile = new File("path/to/your/video.mp4");
            Media media = new Media(videoFile.toURI().toString());
            MediaPlayer mediaPlayer = new MediaPlayer(media);
            mediaPlayer.setCycleCount(MediaPlayer.INDEFINITE);
            MediaView mediaView = new MediaView(mediaPlayer);

            Scene scene = new Scene(new javafx.scene.Group(mediaView), 800, 600);
            fxPanel.setScene(scene);

            mediaPlayer.play();
        });
    }

    private void openLink(String url) {
        try {
            Desktop.getDesktop().browse(new URI(url));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            AbdulrahimApp app = new AbdulrahimApp();
            app.setVisible(true);
        });
    }
}